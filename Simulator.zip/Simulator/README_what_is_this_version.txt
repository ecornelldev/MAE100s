12/9/22

This version contains the full migration to app designer, plus the removal of updatesim.m and its incorporation into SimulatorGui
It also contains the refactored simulator 

